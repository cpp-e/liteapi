LITEAPI_SUPPORTED_REQUEST_METHODS = ['HEAD', 'DELETE', 'GET', 'PATCH', 'POST', 'PUT']
from .liteapi import liteapi
from .BaseAPIRequest import BaseAPIRequest, APIAuth
from .APIModel import APIModel